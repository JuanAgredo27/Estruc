/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package listacantantes;

import java.util.ArrayList;
import java.util.Collections;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author aslyC
 */
public class Pantalla extends javax.swing.JPanel {
    DefaultTableModel modelo = new DefaultTableModel();
    ArrayList<Cantantes> listaCantantes = new ArrayList<>();
    
    public Pantalla() {
        initComponents();
        
        modelo.addColumn("Nombre");
        modelo.addColumn("Disco mas vendido");
        modelo.addColumn("Total de ventas");
        
        refrescarList();
        
    }
    
    
    
     public void refrescarList(){
        modelo.setRowCount(0);
    
    for (Cantantes cantante : listaCantantes) {
        Object[] row = {cantante.getNombre(), cantante.getMayorVentas(), cantante.getTotalVentas()};
        modelo.addRow(row);
    }
    VerList.setModel(modelo);
       
    }
    
     public void eliminarCantante(int indice ) {
      if (indice >= 0 && indice < listaCantantes.size()) {
        listaCantantes.remove(indice);
        refrescarList();  // Refrescar la lista después de eliminar el cantante
    }
    
    refrescarList();  // Refrescar la lista después de eliminar el cantante
}
     
     public void modificar(int indice, String nombre, String discoVentas, double totalVentas){
           if (indice >= 0 && indice < listaCantantes.size()) {
        Cantantes cantante = listaCantantes.get(indice);
        cantante.setNombre(nombre);
        cantante.setMayorVentas(discoVentas);
        cantante.setTotalVentas(totalVentas);
        refrescarList();  // Actualizar la tabla después de modificar
    } else {
        JOptionPane.showMessageDialog(this, "La fila especificada no existe.");
    }
     }
   private void generarListaVentas() {
    Collections.sort(listaCantantes, (cantante1, cantante2) -> Double.compare(cantante2.getTotalVentas(),
       cantante1.getTotalVentas()));
          refrescarList();

}
    
   @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        Añadir = new javax.swing.JButton();
        modificar = new javax.swing.JButton();
        Eliminar = new javax.swing.JButton();
        Ver = new javax.swing.JButton();
        Nombre = new javax.swing.JTextField();
        DiscoVen = new javax.swing.JTextField();
        TotalVen = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        VerList = new javax.swing.JTable();
        Salir = new javax.swing.JButton();

        setBackground(new java.awt.Color(153, 153, 153));
        setForeground(new java.awt.Color(255, 204, 204));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("LISTA DE FAMOSOS ARTISTAS");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(68, 6, 540, 60));

        Añadir.setBackground(new java.awt.Color(0, 0, 0));
        Añadir.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        Añadir.setForeground(new java.awt.Color(255, 255, 255));
        Añadir.setText("AÑADIR");
        Añadir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AñadirActionPerformed(evt);
            }
        });
        add(Añadir, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 410, 120, 40));

        modificar.setBackground(new java.awt.Color(0, 0, 0));
        modificar.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        modificar.setForeground(new java.awt.Color(255, 255, 255));
        modificar.setText("MODIFICAR");
        modificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificarActionPerformed(evt);
            }
        });
        add(modificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 410, 120, 40));

        Eliminar.setBackground(new java.awt.Color(0, 0, 0));
        Eliminar.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        Eliminar.setForeground(new java.awt.Color(255, 255, 255));
        Eliminar.setText("ELIMINAR");
        Eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarActionPerformed(evt);
            }
        });
        add(Eliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 410, 120, 40));

        Ver.setBackground(new java.awt.Color(0, 0, 0));
        Ver.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        Ver.setForeground(new java.awt.Color(255, 255, 255));
        Ver.setText("VER VENTAS");
        Ver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VerActionPerformed(evt);
            }
        });
        add(Ver, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 410, 120, 40));

        Nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NombreActionPerformed(evt);
            }
        });
        add(Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, 178, -1));
        add(DiscoVen, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, 176, -1));

        TotalVen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TotalVenActionPerformed(evt);
            }
        });
        add(TotalVen, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 240, 180, -1));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel3.setText("NOMBRE");
        add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 178, -1));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel4.setText("DISCO DE VENTAS");
        add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 176, -1));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel5.setText("TOTAL DE VENTAS");
        add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, 157, -1));

        VerList.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        VerList.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane4.setViewportView(VerList);

        add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, 590, 250));

        Salir.setBackground(new java.awt.Color(51, 51, 51));
        Salir.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Salir.setForeground(new java.awt.Color(255, 255, 255));
        Salir.setText("Salir");
        Salir.setMaximumSize(new java.awt.Dimension(88, 22));
        Salir.setMinimumSize(new java.awt.Dimension(88, 22));
        Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalirActionPerformed(evt);
            }
        });
        add(Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 410, 100, 40));
    }// </editor-fold>//GEN-END:initComponents

    
    
    private void VerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VerActionPerformed
        generarListaVentas();
    }//GEN-LAST:event_VerActionPerformed

    private void modificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificarActionPerformed
   String input = JOptionPane.showInputDialog(this, "Ingrese el número de fila a modificar:");
    try {
        int rowIndex = Integer.parseInt(input);
        if (rowIndex >= 0 && rowIndex < VerList.getRowCount()) {
            String nombre = Nombre.getText();
            String discoVentas = DiscoVen.getText();
            double totalVentas = 0.0;
            
            try {
                totalVentas = Double.parseDouble(TotalVen.getText());
                modificar(rowIndex, nombre, discoVentas, totalVentas);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Ingrese un valor válido para Total de Ventas.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "La fila especificada no existe.");
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Ingrese un número válido de fila.");
    }
    }//GEN-LAST:event_modificarActionPerformed

    private void AñadirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AñadirActionPerformed
      
        try {
            Cantantes cantante = new Cantantes();
            cantante.setNombre(Nombre.getText());
            cantante.setMayorVentas(DiscoVen.getText());
            cantante.setTotalVentas(Double.parseDouble(TotalVen.getText().toString()));
            
            Nombre.setText("  ");
            DiscoVen.setText("  ");
            TotalVen.setText("  ");
            listaCantantes.add(cantante);
       
            refrescarList();
        }
        catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Llenar correctamente los espacios ");
        }
 
    }//GEN-LAST:event_AñadirActionPerformed

    private void NombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NombreActionPerformed
       
    }//GEN-LAST:event_NombreActionPerformed

    private void TotalVenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TotalVenActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TotalVenActionPerformed

    private void EliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarActionPerformed
     String input = JOptionPane.showInputDialog(this, "Ingrese el número de fila a eliminar:");
    try {
        int rowIndex = Integer.parseInt(input);
        eliminarCantante(rowIndex);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Ingrese un número válido de fila.");
    }
    
    }//GEN-LAST:event_EliminarActionPerformed

    private void SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalirActionPerformed
        JFrame frame = (JFrame) getTopLevelAncestor();
    
    // Cerrar el JFrame y finalizar la aplicación
    frame.dispose();
    System.exit(0);
    }//GEN-LAST:event_SalirActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Añadir;
    private javax.swing.JTextField DiscoVen;
    private javax.swing.JButton Eliminar;
    private javax.swing.JTextField Nombre;
    private javax.swing.JButton Salir;
    private javax.swing.JTextField TotalVen;
    private javax.swing.JButton Ver;
    private javax.swing.JTable VerList;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JButton modificar;
    // End of variables declaration//GEN-END:variables
public class Main {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Lista de Cantantes");
        Pantalla panel = new Pantalla();

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.getContentPane().add(panel);
        frame.setVisible(true);
    }
}
}


