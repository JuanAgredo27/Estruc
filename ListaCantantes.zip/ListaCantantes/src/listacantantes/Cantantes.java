
package listacantantes;

/**
 *
 * @author AslyC
 */
class Cantantes {
    private String nombre;
    private String mayorVentas;
    private double totalVentas;

    public Cantantes() {
    }

    public Cantantes( String Nombre, String MayorVentas, double TotalVentas){
        this.nombre = nombre;
        this.mayorVentas = mayorVentas;
        this.totalVentas = totalVentas;
        
    }

    public String getNombre() {
        return nombre;
    }

    public String getMayorVentas() {
        return mayorVentas;
    }

    public double getTotalVentas() {
        return totalVentas;
    }
   public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setMayorVentas(String mayorVentas) {
        this.mayorVentas = mayorVentas;
    }

    public void setTotalVentas(double totalVentas) {
        this.totalVentas = totalVentas;
    }
 
    }
    
